package com.trigyn.jpalms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaLmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaLmsApplication.class, args);
	}

}
