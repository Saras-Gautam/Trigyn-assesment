package com.trigyn.jpalms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaLmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
