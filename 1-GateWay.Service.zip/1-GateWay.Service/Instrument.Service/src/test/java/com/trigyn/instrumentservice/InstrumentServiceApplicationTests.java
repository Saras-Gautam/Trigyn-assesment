package com.trigyn.instrumentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InstrumentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
